# مشروع خدماتي — Android APK مستقل

هذا المشروع يغلّف نسخة خدماتي الحالية داخل تطبيق Android مستقل بواجهة WebView، لذلك لا تظهر واجهة Chrome للمستخدم.

## مهم قبل نشره كتحديث على APKPure

يجب أن يكون `applicationId` في `app/build.gradle` مطابقًا تمامًا لمعرّف الحزمة الموجود في نسخة APK المنشورة حاليًا على APKPure. القيمة الموضوعة حاليًا هي:

`io.github.mldbj26937vbjd793hdi_a11y.twa`

تم ضبطه الآن ليطابق Package Name الظاهر في APKPure.

كذلك ارفع `versionCode` إلى 2 في هذه النسخة، مع versionName `1.0.0.1`.

## البناء

افتح المجلد في Android Studio ثم:

Build → Generate App Bundle / APK → Generate APK

المشروع لا يحتاج مكتبات Firebase Android لأن Firebase المستخدم حاليًا يعمل داخل صفحة الويب نفسها.

## الروابط والإعلانات

تم ضبط WebView لإبقاء روابط HTTP/HTTPS داخل التطبيق قدر الإمكان. الروابط الخاصة مثل `tel:` و`mailto:` تُرسل إلى التطبيق المناسب على الهاتف.

شبكة الإعلانات قد تفرض سلوك فتح خارجي لبعض الروابط؛ لذلك لا يمكن ضمان أن كل صفحة هبوط إعلانية ستبقى داخل WebView إذا فرضت الشبكة فتحًا خارجيًا.

## الإشعارات

منطق Firebase Web الموجود في الصفحة محفوظ، لكن Push Web/FCM داخل WebView لا يُعامل كإشعارات Android Native. إذا أردنا إشعارات Android أصلية موثوقة في النسخة النهائية، نضيف Firebase Cloud Messaging Native إلى المشروع.
